# load in the package
library(gradeR)

calcGradesForGradescope("Lesson_4_Assignment_Data_Manipulation_with_dplyr_Part_1.R",       # each student's submission must be named this!
                        "Lesson_4_Assignment_Tests.R") # the file with all of the testthat tests 
  
